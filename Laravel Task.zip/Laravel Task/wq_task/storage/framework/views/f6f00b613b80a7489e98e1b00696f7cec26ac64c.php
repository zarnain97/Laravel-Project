<?php $__env->startSection('content'); ?>

<head>
<title>user info</title>
</head>
<body>
    <center>
        <h2>Add Users</h2>
<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <?php echo e(session('status')); ?>

</div>
<?php elseif(session('failed')): ?>
<div class="alert alert-danger" role="alert">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <?php echo e(session('failed')); ?>

</div>
<?php endif; ?>
<form action = "/create" method = "post">
    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
    <table>
    <tr>
    <td>First Name</td>
    <td><input type='text' name='first_name' /></td>
    <tr>
    <td>Last Name</td>
    <td><input type="text" name='last_name'/></td>
    </tr>
    <tr>
    <td>City Name</td>
    <td>
    <select name="city_name">
    <option value="peshawar">Peshawar</option>
    <option value="lahore">Lahore</option>
    <option value="Karachi">Karachi</option>
    </select></td>
    </tr>
    <tr>
    <td>Email</td>
    <td><input type="text" name='email'/></td>
    </tr>

    <tr>
    <td colspan = '2'>
    <input type = 'submit' value = "Add User"/>
    </td>
    </tr>
    </table>
</form>
</body>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>