<?php $__env->startSection('content'); ?>

<head>
<title>View User Records</title>
</head>
<body>
	 <center>
        <h2>All Users</h2>
<table border = "1">
<tr>
<td>Id</td>	
<td>First Name</td>
<td>Last Name</td>
<td>City Name</td>
<td>Email</td>
<td>Update</td>
<td>Remove</td>
</tr>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($user->user_id); ?></td>
<td><?php echo e($user->first_name); ?></td>
<td><?php echo e($user->last_name); ?></td>
<td><?php echo e($user->city_name); ?></td>
<td><?php echo e($user->email); ?></td>
<td><a href = 'edit/<?php echo e($user->user_id); ?>'>Edit</a></td>
<td><a href = 'delete/<?php echo e($user->user_id); ?>'>Delete</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>