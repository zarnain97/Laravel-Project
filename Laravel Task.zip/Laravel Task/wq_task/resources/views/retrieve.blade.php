@extends('layouts.app')

@section('content')

<head>
<title>View User Records</title>
</head>
<body>
	 <center>
        <h2>All Users</h2>
<table border = "1">
<tr>
<td>Id</td>	
<td>First Name</td>
<td>Last Name</td>
<td>City Name</td>
<td>Email</td>
<td>Update</td>
<td>Remove</td>
</tr>
@foreach ($users as $user)
<tr>
<td>{{ $user->user_id }}</td>
<td>{{ $user->first_name }}</td>
<td>{{ $user->last_name }}</td>
<td>{{ $user->city_name }}</td>
<td>{{ $user->email }}</td>
<td><a href = 'edit/{{ $user->user_id }}'>Edit</a></td>
<td><a href = 'delete/{{ $user->user_id }}'>Delete</a></td>
</tr>
@endforeach
</table>
</body>
</center>
@endsection