<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userInfo extends Model
{
    protected $table = 'register';
	public $timestamps = false;
 
 	protected $fillable = [
		'first_name', 'last_name','city_name', 'email',
	];
}
